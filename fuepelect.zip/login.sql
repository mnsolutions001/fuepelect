SELECT * FROM users WHERE matric_number = '123456' AND jamb_number = '789101';
