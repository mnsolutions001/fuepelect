INSERT INTO users (matric_number, jamb_number, password, face_image)
VALUES ('123456', '789101', '$2y$10$hashedpassword...', 'path/to/face/image.jpg');
