-- Insert the user's vote
INSERT INTO votes (user_id, candidate_id)
VALUES (1, 1);  -- Assume user_id=1 voted for candidate_id=1

-- Update the candidate's vote count
UPDATE candidates SET votes = votes + 1 WHERE id = 1;
