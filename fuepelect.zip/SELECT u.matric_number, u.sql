SELECT u.matric_number, u.jamb_number, c.name, c.position
FROM users u
JOIN votes v ON u.id = v.user_id
JOIN candidates c ON v.candidate_id = c.id
WHERE u.id = 1;  -- Assume the user ID is 1
