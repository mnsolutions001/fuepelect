-- Create the database
CREATE DATABASE campus_evoting;

USE campus_evoting;

-- Create table for users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,               -- Unique ID for each user
    matric_number VARCHAR(50) NOT NULL UNIQUE,        -- User's matriculation number
    jamb_number VARCHAR(50) NOT NULL UNIQUE,          -- User's JAMB number
    password VARCHAR(255) NOT NULL,                   -- User's password (hashed)
    face_image VARCHAR(255),                          -- Path to stored face image for verification
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp for registration
);

-- Create table for candidates
CREATE TABLE candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,               -- Unique ID for each candidate
    name VARCHAR(100) NOT NULL,                       -- Candidate's name
    position VARCHAR(100) NOT NULL,                   -- Position the candidate is running for
    votes INT DEFAULT 0,                              -- Number of votes the candidate has received
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP    -- Timestamp for when the candidate was added
);

-- Create table for votes
CREATE TABLE votes (
    id INT AUTO_INCREMENT PRIMARY KEY,               -- Unique ID for each vote
    user_id INT,                                     -- Foreign Key referencing the user
    candidate_id INT,                                -- Foreign Key referencing the candidate
    vote_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   -- Timestamp for when the vote was cast
    FOREIGN KEY (user_id) REFERENCES users(id),      -- Foreign Key constraint for user
    FOREIGN KEY (candidate_id) REFERENCES candidates(id), -- Foreign Key constraint for candidate
    UNIQUE (user_id)                                 -- Ensure each user can only vote once
);

-- Example Data Insertion (For testing purposes)
-- Add users
INSERT INTO users (matric_number, jamb_number, password)
VALUES ('123456', '789101', '$2y$10$W8kL6bxtEVrM5UprzMJ4ueyC.eA7mW7gQYwgjbWptPbzS5P8yD7v5'); -- password is "password123" hashed with bcrypt

-- Add candidates
INSERT INTO candidates (name, position)
VALUES ('John Doe', 'President'),
       ('Jane Smith', 'Vice President'),
       ('Mark Johnson', 'Secretary');

-- Insert a sample vote (for testing purposes)
-- The user with ID=1 votes for Candidate with ID=1
INSERT INTO votes (user_id, candidate_id)
VALUES (1, 1);
