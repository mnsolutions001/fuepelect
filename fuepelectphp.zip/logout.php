<?php
session_start();
session_destroy();
echo "You have logged out.";
header("Location: index.php"); // Redirect to the login page
exit;
?>
