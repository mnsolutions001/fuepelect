<?php
require 'db.php';

$stmt = $pdo->prepare("SELECT c.name, c.position, c.votes FROM candidates c ORDER BY c.votes DESC");
$stmt->execute();
$candidates = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h2>Vote Summary</h2>";
foreach ($candidates as $candidate) {
    echo "<p>{$candidate['name']} ({$candidate['position']}) - {$candidate['votes']} votes</p>";
}
?>
