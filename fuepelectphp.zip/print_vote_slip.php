<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    echo "Please log in first.";
    exit;
}

$user_id = $_SESSION['user_id'];

// Get the user's vote information
$stmt = $pdo->prepare("SELECT u.matric_number, u.jamb_number, c.name, c.position
                       FROM users u
                       JOIN votes v ON u.id = v.user_id
                       JOIN candidates c ON v.candidate_id = c.id
                       WHERE u.id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$vote = $stmt->fetch(PDO::FETCH_ASSOC);

if ($vote) {
    echo "<h2>Your Voting Slip</h2>";
    echo "<p><strong>Matriculation Number:</strong> {$vote['matric_number']}</p>";
    echo "<p><strong>JAMB Number:</strong> {$vote['jamb_number']}</p>";
    echo "<p><strong>Voted Candidate:</strong> {$vote['name']} - {$vote['position']}</p>";
    echo "<button onclick='window.print()'>Print Voting Slip</button>";
} else {
    echo "You haven't voted yet.";
}
?>
