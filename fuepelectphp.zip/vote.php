<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo "Please log in first.";
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle voting action
if (isset($_POST['vote'])) {
    $candidate_id = $_POST['candidate'];

    // Check if the user has already voted
    $stmt = $pdo->prepare("SELECT * FROM votes WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $existing_vote = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_vote) {
        echo "You have already voted!";
    } else {
        // Insert the vote into the database
        $stmt = $pdo->prepare("INSERT INTO votes (user_id, candidate_id) VALUES (:user_id, :candidate_id)");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':candidate_id', $candidate_id);
        $stmt->execute();

        // Update the candidate's vote count
        $stmt = $pdo->prepare("UPDATE candidates SET votes = votes + 1 WHERE id = :candidate_id");
        $stmt->bindParam(':candidate_id', $candidate_id);
        $stmt->execute();

        echo "Vote cast successfully!";
    }
}
?>

<!-- Display voting page -->
<form method="post">
    <h2>Select Your Candidate</h2>
    <label>
        <input type="radio" name="candidate" value="1" required> Candidate 1 - President
    </label><br>
    <label>
        <input type="radio" name="candidate" value="2" required> Candidate 2 - Vice President
    </label><br>
    <label>
        <input type="radio" name="candidate" value="3" required> Candidate 3 - Secretary
    </label><br>
    <button type="submit" name="vote">Vote</button>
</form>

<a href="logout.php">Logout</a>
