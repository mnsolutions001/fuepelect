<?php
require 'db.php';

// Handle login
if (isset($_POST['login'])) {
    $matric_number = $_POST['matric_number'];
    $jamb_number = $_POST['jamb_number'];
    $password = $_POST['password'];

    // Prepare SQL to find the user
    $stmt = $pdo->prepare("SELECT * FROM users WHERE matric_number = :matric_number AND jamb_number = :jamb_number");
    $stmt->bindParam(':matric_number', $matric_number);
    $stmt->bindParam(':jamb_number', $jamb_number);
    $stmt->execute();
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Simulate face verification (replace with real face verification logic)
        if (true) {  // Face verification success
            session_start();
            $_SESSION['user_id'] = $user['id'];
            echo "Login successful. Redirecting to voting page...";
            header("Location: vote.php");
        } else {
            echo "Face verification failed.";
        }
    } else {
        echo "Invalid credentials!";
    }
}

// Handle user registration (for testing purposes)
if (isset($_POST['register'])) {
    $matric_number = $_POST['matric_number'];
    $jamb_number = $_POST['jamb_number'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Insert new user into the database
    $stmt = $pdo->prepare("INSERT INTO users (matric_number, jamb_number, password) VALUES (:matric_number, :jamb_number, :password)");
    $stmt->bindParam(':matric_number', $matric_number);
    $stmt->bindParam(':jamb_number', $jamb_number);
    $stmt->bindParam(':password', $password);
    $stmt->execute();

    echo "User registered successfully.";
}
?>
